import re
from flask import Flask, request, render_template, session, redirect
app = Flask(__name__)
import pymongo
import os
from datetime import datetime, timedelta
from bson import ObjectId
my_client = pymongo.MongoClient("mongodb://localhost:27017/")
my_db = my_client["Hospital_management"]
hospital_col = my_db['Hospital']
doctor_col = my_db['Doctor']
patient_col = my_db['Patient']
doctor_timing_col = my_db["Doctor_timings"]
appointment_col = my_db['Appointment']
payment_col = my_db['Payment']
prescription_col = my_db['Prescription']
APP_ROOT = os.path.dirname(os.path.abspath(__file__))
APP_ROOT = APP_ROOT + "/static/images"
app.secret_key="key"

@app.route("/")
def index():
    return render_template('index.html')

@app.route("/alogin")
def alogin():
    return render_template("alogin.html")

@app.route("/alogin1", methods=['post'])
def alogin1():
    username = request.form.get("username")
    password = request.form.get("password")
    if username == 'admin' and password == 'admin':
        session['role'] = 'admin'
        return render_template("admin_home.html")
    return render_template("msg.html", msg="Invalid Details", color='bg-danger')

@app.route("/admin_home")
def admin_home():
    return render_template('admin_home.html')


@app.route("/add_hospitals")
def add_hospitals():
    return render_template("add_hospitals.html")


@app.route("/add_hospital1", methods=['post'])
def add_hospital1():
    name = request.form.get('name')
    email = request.form.get('email')
    phone = request.form.get('phone')
    password = request.form.get('password')
    address = request.form.get('address')
    query = {'$or': [{"email": email}, {'phone': phone}]}
    count = hospital_col.count_documents(query)
    if count > 0:
        return render_template("amsg.html", amsg="Hospital exits", color='bg-danger p-3')
    query = {'name': name, "email": email, 'phone': phone, 'password': password, 'address': address}
    hospital_col.insert_one(query)
    return render_template("amsg.html", amsg="Hospital Added Successfully", color='bg-success')

@app.route("/hlogin")
def hlogin():
    return render_template("hlogin.html")

@app.route("/hlogin1", methods=['post'])
def hlogin1():
    email = request.form.get("email")
    password = request.form.get("password")
    query = {"email": email, "password": password}
    count = hospital_col.count_documents(query)
    if count > 0:
        hospital = hospital_col.find_one(query)
        session['hospital_id'] = str(hospital['_id'])
        session['role'] = 'hospital'
        return redirect('/hospital_home')
    return render_template("msg.html", msg="Invalid Details")


@app.route("/hospital_home")
def hospital_home():
    return render_template("hospital_home.html")


@app.route("/view_hospitals")
def view_hospitals():
    query = {}
    if session['role']=='hospital':
        query = {'_id': ObjectId(session['hospital_id'])}
    hospitals = hospital_col.find(query)
    return render_template("view_hospitals.html", hospitals=hospitals)


@app.route("/add_doctors")
def add_doctors():
    return render_template("add_doctors.html")

@app.route("/dreg1", methods=['post'])
def dreg1():
    name = request.form.get('name')
    email = request.form.get('email')
    phone = request.form.get('phone')
    password = request.form.get('password')
    hospital_id = request.form.get('hospital_id')
    print(hospital_id)
    department = request.form.get('department')
    consultation_fee = request.form.get('consultation_fee')
    query = {'$or': [{"email": email}, {'phone': phone}]}
    count = doctor_col.count_documents(query)
    if count > 0:
        return render_template("msg.html", msg="Duplicate Doctor Details", color='bg-danger p-2')
    query = {'name': name, "email": email, 'phone': phone, 'password': password, 'department': department, 'hospital_id': ObjectId(hospital_id), 'consultation_fee':consultation_fee}
    doctor_col.insert_one(query)
    return render_template("msg.html", msg="Doctor Registration Successful", color='bg-success p-2')


@app.route("/add_doctors1", methods=['post'])
def add_doctors1():
    name = request.form.get('name')
    email = request.form.get('email')
    phone = request.form.get('phone')
    password = request.form.get('password')
    department = request.form.get('department')
    consultation_fee = request.form.get('consultation_fee')
    query = {'$or': [{"email": email}, {'phone': phone}]}
    count = doctor_col.count_documents(query)
    if count > 0:
        return render_template("hmsg.html", hmsg="Doctor exits", color='bg-danger p-3 text-white')
    query = {'name': name, "email": email, 'phone': phone, 'password': password, 'department': department, 'hospital_id': ObjectId(session['hospital_id']), 'consultation_fee':consultation_fee}
    doctor_col.insert_one(query)
    return render_template("hmsg.html", hmsg="Doctor Added Successfully", color='bg-success p-3 text-white')



@app.route("/dlogin")
def dlogin():
    return render_template("dlogin.html")

@app.route("/dlogin1",methods=['post'])
def dlogin1():
    email = request.form.get("email")
    password = request.form.get("password")
    query = {"email": email, "password": password}
    count = doctor_col.count_documents(query)
    if count > 0:
        doctor = doctor_col.find_one(query)
        session['doctor_id'] = str(doctor['_id'])
        session['role'] = 'doctor'
        return redirect('/doctor_home')
    return render_template("msg.html", msg="Invalid Details")


@app.route("/doctor_home")
def doctor_home():
    return render_template("doctor_home.html")


@app.route("/preg")
def preg():
    return render_template("preg.html")


@app.route("/preg1", methods=['post'])
def preg1():
    name = request.form.get("name")
    email = request.form.get("email")
    phone = request.form.get("phone")
    password = request.form.get("password")
    age = request.form.get("age")
    insurance = request.files.get("insurance")
    print(insurance.filename)
    filename=''
    if insurance.filename != '':
        path = APP_ROOT + "/" + insurance.filename
        filename= insurance.filename
        insurance.save(path)
    gender = request.form.get("gender")
    query = {'$or': [{'email': email}, {'phone': phone}]}
    count = patient_col.count_documents(query)
    if count > 0:
        return render_template("msg.html", msg='Patient Exits')
    query = {"name": name, "email": email, "phone": phone, "password": password, 'age': age, 'insurance':  filename,'gender':gender}
    patient_col.insert_one(query)
    return render_template('msg.html', msg='registration successful')





@app.route("/plogin")
def plogin():
    return render_template("plogin.html")

@app.route("/plogin1",methods=['post'])
def plogin1():
    email = request.form.get("email")
    password = request.form.get("password")
    query = {"email": email, "password": password}
    count = patient_col.count_documents(query)
    if count > 0:
        patient = patient_col.find_one(query)
        session['patient_id'] = str(patient['_id'])
        session['role'] = 'patient'
        return redirect('/patient_home')
    return render_template("msg.html", msg="Invalid Details")


@app.route("/patient_home")
def patient_home():
    return render_template("patient_home.html")

@app.route('/doctor_timings')
def doctor_timings():
    weekdays = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday']
    return render_template('doctor_timings.html', weekdays=weekdays, get_doctor_timings=get_doctor_timings)

def get_doctor_timings(day):
    query = {'day': day, 'doctor_id': ObjectId(session['doctor_id'])}
    doctor_timing = doctor_timing_col.find_one(query)
    return doctor_timing




@app.route('/doctor_timings1', methods=['post'])
def doctor_timings1():
    doctor_id = session['doctor_id']
    day = request.form.get('day')
    open_time = request.form.get('open_time')
    close_time = request.form.get('close_time')
    slot_duration = request.form.get('slot_duration')
    query = {'day': day, 'doctor_id': ObjectId(doctor_id)}
    doctor_timings = doctor_timing_col.find_one(query)
    if doctor_timings == None:
        query = {'day': day, 'open_time': open_time, 'close_time': close_time, 'slot_duration': slot_duration, 'doctor_id': ObjectId(doctor_id)}
        doctor_timing_col.insert_one(query)
    else:
        query2 = {'$set': {'open_time': open_time, 'close_time': close_time, 'slot_duration': slot_duration}}
        doctor_timing_col.update_one(query, query2)
    return redirect('/doctor_timings')

@app.route("/dreg")
def dreg():
    hospitals = hospital_col.find()
    return render_template("dreg.html",hospitals=hospitals)

@app.route('/view_doctors')
def view_doctors():
    hospital_id = None
    if session['role'] == 'patient':
        hospital_id = request.args.get('hospital_id')
        if hospital_id == None or hospital_id == '':
            query = {}
        else:
            query = {'hospital_id': ObjectId(hospital_id)}
    elif session['role'] == 'hospital':
        query = {'hospital_id': ObjectId(session['hospital_id'])}
    elif session['role'] == 'doctor':
        query = {'_id': ObjectId(session['doctor_id'])}
    doctors = doctor_col.find(query)
    hospitals = hospital_col.find()
    return render_template("view_doctors.html", hospitals=hospitals, doctors=doctors, hospital_id=hospital_id,getHospital=getHospital, str=str)


@app.route('/appointment')
def appointment():
    weekDays = ['Monday','Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday']
    doctor_id = request.args.get("doctor_id")
    booking_date = request.args.get('booking_date')
    booking_date2 = datetime.strptime(booking_date, '%Y-%m-%d')
    day = booking_date2.weekday()
    day = weekDays[day]
    query = {'doctor_id': ObjectId(doctor_id), 'day': day}
    doctor_timing = doctor_timing_col.find_one(query)
    slots = []
    if doctor_timing == None:
        return render_template('pmsg.html', pmsg='Slots not available not for this doctor')
    open_time = doctor_timing['open_time']
    close_time = doctor_timing['close_time']
    current_date_time = datetime.date(datetime.now())
    date = str(current_date_time)+' '+(open_time)
    date2 = str(current_date_time) + ' ' + (close_time)
    date_time = datetime.strptime(date, '%Y-%m-%d %H:%M')
    date_time2 = datetime.strptime(date2, '%Y-%m-%d %H:%M')
    slot_number = 0
    slots = []
    while date_time < date_time2:
        from_date = date_time
        to_date = from_date + timedelta(minutes=15)
        date_time = to_date
        fromTime =from_date.strftime('%H:%M')
        toTime = to_date.strftime('%H:%M')
        slot_number = slot_number+1
        slots.append({'fromTime': fromTime, 'toTime': toTime, 'slot_number': slot_number})
    patient = patient_col.find_one({"_id":ObjectId(session['patient_id'])})
    slots = list(slots)
    if len(slots) == 0:
        return render_template('pmsg.html', pmsg='Slots Not available not for this doctors')
    return render_template("appointment.html", slots=slots,doctor_id=doctor_id, doctor_timing_id=doctor_timing['_id'], booking_date=booking_date, get_doctor_by_id=get_doctor_by_id,isSlotBooked=isSlotBooked, patient=patient, float=float)

def get_doctor_by_id(doctor_id):
    query = {'_id': ObjectId(doctor_id)}
    doctor = doctor_col.find_one(query)
    return doctor

@app.route('/appointment1', methods=['post'])
def appointment1():
    doctor_id = request.form.get("doctor_id")
    doctor_timing_id = request.form.get('doctor_timing_id')
    slot = request.form.get('slot')
    cause = request.form.get('cause')
    consultation_fee = request.args.get('consultation_fee')
    booking_date = request.form.get('booking_date')
    query = {'doctor_id': ObjectId(doctor_id), 'doctor_timing_id': ObjectId(doctor_timing_id), 'slot': slot, 'cause': cause, 'patient_id':ObjectId(session['patient_id']),'booking_date':booking_date, 'status': 'Booked'}
    result = appointment_col.insert_one(query)
    appointment_id = result.inserted_id
    doctor = doctor_col.find_one({"_id": ObjectId(doctor_id)})
    # query = {'appointment_id': ObjectId(appointment_id), 'patient_id': ObjectId(session['patient_id']), "booking_date":datetime.now(),'bill_amount': doctor['consultation_fee']}
    # payment_col.insert_one(query)
    return render_template('pmsg.html', pmsg='Appointment Booked')

@app.route('/view_appointments')
def view_appointments():
    query = {}
    if session['role'] =='patient':
        query = {'patient_id': ObjectId(session['patient_id'])}
    appointments = appointment_col.find(query)
    appointments = list(appointments)
    if len(appointments)==0:
        return render_template('pmsg.html', pmsg='Appointments not available')
    return render_template('view_appointments.html', appointments=appointments, get_doctor_by_id=get_doctor_by_id, get_patient_by_id=get_patient_by_id)

def get_patient_by_id(patient_id):
    query = {'_id': patient_id}
    patient = patient_col.find_one(query)
    return patient

@app.route('/cancel_appointment')
def cancel_appointment():
    appointment_id = request.args.get('appointment_id')
    query = {'_id': ObjectId(appointment_id)}
    query2 = {'$set': {'status':'cancelled_appointment'}}
    appointment_col.update_one(query, query2)
    return redirect('/view_appointments')


def isSlotBooked(booking_date,doctor_id,slot):
    query = {"booking_date":booking_date, "doctor_id": ObjectId(doctor_id), "slot": slot, "$or":[{"status":"Booked"},{"status": "Prescribed"}]}
    count = appointment_col.count_documents(query)
    if count == 0:
        return False;
    else:
        return True

def getAppointment(booking_date,doctor_id,slot):
    query = {"booking_date":booking_date, "doctor_id": ObjectId(doctor_id), "slot": slot, "$or":[{"status":"Booked"},{"status": "Prescribed"}]}
    appointment = appointment_col.find_one(query)
    return appointment;

@app.route('/view_doctor_appointments')
def view_doctor_appointments():
    appointment_id = request.args.get('appointment_id')
    booking_date = request.args.get('booking_date')
    if booking_date == None:
        booking_date = datetime.today().strftime('%Y-%m-%d')

    doctor_id = session['doctor_id']
    query = {'doctor_id': ObjectId(doctor_id), 'booking_date': booking_date}
    if appointment_id!=None:
        query = {"_id": ObjectId(appointment_id)}
    appointments = appointment_col.find(query)
    appointments = list(appointments)

    return render_template('view_doctor_appointments.html', appointments=appointments, booking_date=booking_date,get_doctor_by_id=get_doctor_by_id, get_patient_by_id=get_patient_by_id, len=len)

@app.route('/reject_appointment')
def reject_appointment():
    appointment_id = request.args.get('appointment_id')
    booking_date = request.args.get('booking_date')
    query = {'_id': ObjectId(appointment_id)}
    query2 = {'$set': {'status': 'Appointment_rejected'}}
    appointment_col.update_one(query, query2)
    return redirect('/view_doctor_appointments?booking_date='+str(booking_date))


@app.route('/give_prescription')
def give_prescription():
    appointment_id = request.args.get('appointment_id')
    return render_template('give_prescription.html', appointment_id=appointment_id)
@app.route('/give_note')
def give_note():
    appointment_id = request.args.get('appointment_id')
    return render_template('give_note.html', appointment_id=appointment_id)


@app.route('/give_prescription1', methods=['post'])
def give_prescription1():
    appointment_id = request.form.get('appointment_id')
    medicines = request.form.get('medicines')
    comments = request.form.get('comments')
    query = {'appointment_id': ObjectId(appointment_id), 'medicines': medicines, 'comments': comments, 'date':datetime.now()}
    prescription_col.insert_one(query)
    query = {'_id': ObjectId(appointment_id)}
    query2 = {'$set': {'status': 'Prescribed'}}
    appointment_col.update_one(query, query2)
    return render_template('dmsg.html', dmsg='Prescription Added')

@app.route('/give_note1', methods=['post'])
def give_note1():
    appointment_id = request.form.get('appointment_id')
    comments = request.form.get('comments')
    query = {'appointment_id': ObjectId(appointment_id), 'comments': comments, 'date':datetime.now()}
    prescription_col.insert_one(query)
    query = {'_id': ObjectId(appointment_id)}
    query2 = {'$set': {'status': 'Note Given'}}
    appointment_col.update_one(query, query2)
    return render_template('dmsg.html', dmsg='The note given to patient')


@app.route('/view_prescription')
def view_prescription():
    appointment_id = request.args.get('appointment_id')
    query = {'appointment_id': ObjectId(appointment_id)}
    prescription = prescription_col.find_one(query)
    return render_template('view_prescription.html', prescription=prescription)
@app.route('/view_note')
def view_note():
    appointment_id = request.args.get('appointment_id')
    query = {'appointment_id': ObjectId(appointment_id)}
    prescription = prescription_col.find_one(query)
    return render_template('view_note.html', prescription=prescription)

@app.route("/paybill")
def paybill():
    appointment_id = request.args.get('appointment_id')
    query = {"_id": ObjectId(appointment_id)}
    appointment = appointment_col.find_one(query)
    print(appointment)
    patient = patient_col.find_one({"_id":ObjectId(session['patient_id'])})
    return render_template("paybill.html", appointment=appointment,get_doctor_by_id=get_doctor_by_id,patient=patient,float=float)
@app.route('/view_bill')
def view_bill():
    appointment_id = request.args.get('appointment_id')
    query = {"appointment_id": ObjectId(appointment_id)}
    payment_details = payment_col.find(query)
    return render_template('view_bill.html',appointment_id=appointment_id, get_patient_by_id=get_patient_by_id, get_appointment_id=get_appointment_id, get_doctor_by_doctor_id=get_doctor_by_doctor_id, payment_details=payment_details)

def get_appointment_id(appointment_id):
    query = {'_id': appointment_id}
    appointment = appointment_col.find_one(query)
    return appointment


def get_doctor_by_doctor_id(doctor_id):
     query = {'_id':doctor_id}
     doctor = doctor_col.find_one(query)
     return  doctor


@app.route("/doctor_slots")
def doctor_slots():
    booking_date = request.args.get('booking_date')
    if booking_date==None:
        booking_date = datetime.today().strftime('%Y-%m-%d')
        booking_date = str(booking_date)
    weekDays = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday']
    booking_date2 = datetime.strptime(booking_date, '%Y-%m-%d')
    day = booking_date2.weekday()
    day = weekDays[day]
    query = {'doctor_id': ObjectId(session['doctor_id']), 'day': day}
    doctor_timing = doctor_timing_col.find_one(query)
    if doctor_timing is None:
        return render_template("dmsg.html", dmsg="Slots Not Available for this doctor", color='bg-success p-3 text-white')
    open_time = doctor_timing['open_time']
    close_time = doctor_timing['close_time']
    current_date_time = datetime.date(datetime.now())
    date = str(current_date_time) + ' ' + (open_time)
    date2 = str(current_date_time) + ' ' + (close_time)
    date_time = datetime.strptime(date, '%Y-%m-%d %H:%M')
    date_time2 = datetime.strptime(date2, '%Y-%m-%d %H:%M')
    slot_number = 0
    slots = []
    while date_time < date_time2:
        from_date = date_time
        to_date = from_date + timedelta(minutes=15)
        date_time = to_date
        fromTime = from_date.strftime('%H:%M')
        toTime = to_date.strftime('%H:%M')
        slot_number = slot_number + 1
        slots.append({'fromTime': fromTime, 'toTime': toTime, 'slot_number': slot_number})
    return render_template("doctor_slots.html",slots=slots,booking_date=booking_date,isSlotBooked=isSlotBooked,getAppointment=getAppointment)


@app.route("/logout")
def logout():
    session.clear()
    return redirect("/")

@app.route("/changeHospital")
def changeHospital():
    doctor = doctor_col.find_one({"_id":ObjectId(session['doctor_id'])})
    query = {"_id": {"$ne": doctor['hospital_id']}}
    print(query)
    hospitals = hospital_col.find(query)
    return render_template("changeHospital.html",hospitals=hospitals)

@app.route("/changeHospital1")
def changeHospital1():
    hospital_id = request.args.get('hospital_id')
    query = {"_id": ObjectId(session['doctor_id'])}
    query2 = {"$set":{"hospital_id": ObjectId(hospital_id)}}
    doctor_col.update_one(query,query2)
    return render_template("dmsg.html", dmsg="Hospital Changed Successfully", color='bg-success p-3 text-white')


def getHospital(hospital_id):
    hospital = hospital_col.find_one({"_id":hospital_id})
    return hospital

@app.route("/paybill1")
def paybill1():
    appointment_id = request.args.get('appointment_id')
    appointment = appointment_col.find_one({"_id": ObjectId(appointment_id)})
    doctor = doctor_col.find_one({"_id": appointment['doctor_id']})
    query = {'appointment_id': ObjectId(appointment_id), 'patient_id': ObjectId(session['patient_id']),
             "booking_date": datetime.now(), 'bill_amount': doctor['consultation_fee']}
    payment_col.insert_one(query)

    query = {"_id": ObjectId(appointment_id)}
    query2 = {"$set": {"status": "Amount Paid"}}
    appointment_col.update_one(query,query2)
    return render_template('pmsg.html', pmsg='Bill Paid Successfully')

app.run(debug=True)
